package comunicacao;

public class CaminhaoController {
}
