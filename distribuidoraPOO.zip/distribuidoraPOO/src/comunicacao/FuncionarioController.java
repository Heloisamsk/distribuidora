package comunicacao;

public class FuncionarioController {
}
