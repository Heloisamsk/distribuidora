package comunicacao;

public class ProdutoController {
}
