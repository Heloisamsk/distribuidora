package comunicacao;

public class ClienteController {
    /* Pacote: comunicacao
Responsabilidade: Transformar dados entre UI/Fachada e Negócios/Dados.

Classes sugeridas:

ClienteController → repassa dados de cliente para Negócios

FuncionarioController

ProdutoController

CaminhaoController

PatioController

AgendamentoController

Podem validar dados, converter DTOs, e chamar os métodos de negócio.

     */
}
