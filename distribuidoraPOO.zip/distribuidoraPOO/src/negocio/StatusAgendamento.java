package negocio;

public enum StatusAgendamento {
    PENDENTE,
    CONFIRMADO,
    CANCELADO,
    CONCLUIDO
}
