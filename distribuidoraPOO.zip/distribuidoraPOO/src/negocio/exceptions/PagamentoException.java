package negocio.exceptions;

public class PagamentoException extends RuntimeException {
    public PagamentoException(String message) {
        super(message);
    }
}