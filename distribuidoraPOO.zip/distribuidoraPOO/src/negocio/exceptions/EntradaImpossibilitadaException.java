package negocio.exceptions;

public class EntradaImpossibilitadaException extends RuntimeException{
    public EntradaImpossibilitadaException(String msg){
        super("msg");
    }
}
