package negocio.exceptions;

public class NotaFiscalException extends RuntimeException {
    public NotaFiscalException(String message) {
        super(message);
    }
}
