package negocio.exceptions;

public class VagaInsuficienteException extends Exception{
    public VagaInsuficienteException(String msg){
        super(msg);
    }
}
