package negocio.exceptions;

public class EstoqueErros extends RuntimeException {
    public EstoqueErros(String mensagem){
        super(mensagem);
    }


}
