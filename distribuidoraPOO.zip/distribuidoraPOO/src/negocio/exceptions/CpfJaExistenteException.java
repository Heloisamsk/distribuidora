package negocio.exceptions;

public class CpfJaExistenteException extends RuntimeException{
    public CpfJaExistenteException(String msg){
        super(msg);

    }
}
