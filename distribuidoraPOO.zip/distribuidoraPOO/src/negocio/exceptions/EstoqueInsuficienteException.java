package negocio.exceptions;

public class EstoqueInsuficienteException extends EstoqueErros{
    public EstoqueInsuficienteException(String mensagem) {
        super(mensagem);
    }
}
