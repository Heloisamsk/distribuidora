package negocio.exceptions;

public class PontoException extends RuntimeException {
    public PontoException(String message) {
        super(message);
    }
}
