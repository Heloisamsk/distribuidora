package negocio.exceptions;

public class ErrosGeralEstoque extends EstoqueErros{
    public ErrosGeralEstoque(String mensagem) {
        super(mensagem);
    }
}
