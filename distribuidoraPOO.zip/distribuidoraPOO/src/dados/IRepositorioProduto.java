/*package dados;

import negocio.Produto;
import java.util.ArrayList;

public interface IRepositorioProduto {
    void cadastrarProduto(Produto produto);
    Produto buscarPorCodigo(String codigo);
    ArrayList<Produto> listarTodos();
    void remover(String codigo);
    void atualizar(Produto produto);
}

 */
