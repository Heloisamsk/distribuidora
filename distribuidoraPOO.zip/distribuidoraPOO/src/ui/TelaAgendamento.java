package ui;

public class TelaAgendamento {// Essas classes chamam métodos da Fachada para executar ações, sem lógica de negócio.
}
