package ui;

public class TelaCadastroFuncionario {
}
